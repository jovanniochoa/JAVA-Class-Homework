import java.util.*;

public class Q4_17 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		int year = 0;
		String month = " ";
		System.out.print("Enter a year: ");
		year = in.nextInt();
		System.out.print("Enter a month: ");
		month = in.next();

		// Test for leap year
		boolean isLeapYear = ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0);
		
		System.out.print(month + " " + year + " has ");
		if (month.equals("Jan") || month.equals("Mar") || month.equals("May") || month.equals("Jul") ||
			month.equals("Aug") || month.equals("Oct") || month.equals("Dec"))
			System.out.println(31 + " days");
		else if (month.equals("Apr") || month.equals("Jun") || month.equals("Sep") || month.equals("Nov"))
			System.out.println(30 + " days");
		else
			if (isLeapYear) {
				System.out.println(29 + " days");
			}
			else {
				System.out.println(28 + " days");
			}
	}

}
